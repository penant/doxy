var searchData=
[
  ['table_5felements_5fper_5fcommutation_5fsector_0',['TABLE_ELEMENTS_PER_COMMUTATION_SECTOR',['../_p_m_s_m_8h.html#a25249376cfc27bd908db02b16abffcbc',1,'PMSM.h']]],
  ['tacho_5foutput_5fenabled_1',['TACHO_OUTPUT_ENABLED',['../_p_m_s_m_8h.html#a012f088cc4fb425a414c5046bd9034df',1,'PMSM.h']]],
  ['tacho_5foutput_5fpin_2',['TACHO_OUTPUT_PIN',['../_p_m_s_m_8h.html#a0b5b986977924785a9ebe6a808c24632',1,'PMSM.h']]],
  ['true_3',['TRUE',['../pid_8h.html#aa8cecfc5c5c054d2875c03e77b7be15d',1,'TRUE():&#160;pid.h'],['../_p_m_s_m_8h.html#aa8cecfc5c5c054d2875c03e77b7be15d',1,'TRUE():&#160;PMSM.h']]],
  ['turn_5fmode_4',['TURN_MODE',['../_p_m_s_m_8h.html#aaf546968d40403737abc1c0d7c21b71d',1,'PMSM.h']]],
  ['turn_5fmode_5fbrake_5',['TURN_MODE_BRAKE',['../_p_m_s_m_8h.html#a787017d9b120f3d96e85d1f907e1202b',1,'PMSM.h']]],
  ['turn_5fmode_5fcoast_6',['TURN_MODE_COAST',['../_p_m_s_m_8h.html#abc931dddd9f7ea3719cd4aa1df315a19',1,'PMSM.h']]]
];
