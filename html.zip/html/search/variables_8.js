var searchData=
[
  ['maxerror_0',['maxError',['../structpid_data.html#abc0df1fd5606b1d182ba271c813dfd8e',1,'pidData']]],
  ['maxsumerror_1',['maxSumError',['../structpid_data.html#a4c337276f8b8dc3ae72afb2b371f1e48',1,'pidData']]],
  ['motorsynchronized_2',['motorSynchronized',['../struct_p_m_s_mflags.html#a8f757d0da362603a85729ad0ea70e9b4',1,'PMSMflags']]]
];
