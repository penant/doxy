var searchData=
[
  ['actualdirection_0',['actualDirection',['../struct_p_m_s_mflags.html#a8d642421b25e2ae10190633371a1cf23',1,'PMSMflags']]],
  ['adc_5fchannel_5fcurrent_1',['ADC_CHANNEL_CURRENT',['../_p_m_s_m_8h.html#acc1eca038155957699dfcb680c6797da',1,'PMSM.h']]],
  ['adc_5fchannel_5fspeed_5fref_2',['ADC_CHANNEL_SPEED_REF',['../_p_m_s_m_8h.html#a434308b8515e774a8b558a2a9deb97f2',1,'PMSM.h']]],
  ['adc_5fprescaler_3',['ADC_PRESCALER',['../_p_m_s_m_8h.html#ab1d0703f6d84b37cbaa587a1a4515dd4',1,'PMSM.h']]],
  ['adc_5fprescaler_5f64_4',['ADC_PRESCALER_64',['../_p_m_s_m_8h.html#a51e4e47f4ef2b5f25be89b958a4bb8a8',1,'PMSM.h']]],
  ['adc_5fprescaler_5f8_5',['ADC_PRESCALER_8',['../_p_m_s_m_8h.html#ab30c91a0c1d57639fbb9aa2e13719d45',1,'PMSM.h']]],
  ['adc_5freference_5fvoltage_6',['ADC_REFERENCE_VOLTAGE',['../_p_m_s_m_8h.html#af557fa4300a3539ea54f1db1773e699f',1,'PMSM.h']]],
  ['adc_5freference_5fvoltage_5faref_7',['ADC_REFERENCE_VOLTAGE_AREF',['../_p_m_s_m_8h.html#a5f954d0687cfcb5fad241ee2c5896d1c',1,'PMSM.h']]],
  ['adc_5freference_5fvoltage_5finternal_8',['ADC_REFERENCE_VOLTAGE_INTERNAL',['../_p_m_s_m_8h.html#aead96d998d5be71e94f680cfe8129ee2',1,'PMSM.h']]],
  ['adc_5freference_5fvoltage_5fvcc_9',['ADC_REFERENCE_VOLTAGE_VCC',['../_p_m_s_m_8h.html#a2cf73c0f278eabd290cfd15bc2a407bf',1,'PMSM.h']]],
  ['adccompleteisr_10',['ADCCompleteISR',['../main_8c.html#a81b96d769ccd714c99b4cd618bd5b5a1',1,'ADCCompleteISR(void):&#160;main.c'],['../_p_m_s_m_8h.html#a81b96d769ccd714c99b4cd618bd5b5a1',1,'ADCCompleteISR(void):&#160;main.c']]],
  ['admux_5fcurrent_11',['ADMUX_CURRENT',['../_p_m_s_m_8h.html#ac6bf33c6961983cea70bfbf8f6e59019',1,'PMSM.h']]],
  ['admux_5fspeed_5fref_12',['ADMUX_SPEED_REF',['../_p_m_s_m_8h.html#ac0b5ae63fe430c4cf1001b059d88e3f5',1,'PMSM.h']]],
  ['advancecommutationsteps_13',['advanceCommutationSteps',['../main_8c.html#a47b8e531c89b5eb9e807c0f28b0940d5',1,'main.c']]],
  ['amplitude_14',['amplitude',['../main_8c.html#a267f7577e1ed6402dc359e31b64431e8',1,'main.c']]]
];
