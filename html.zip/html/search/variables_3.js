var searchData=
[
  ['d_5ffactor_0',['D_Factor',['../structpid_data.html#a1a90165f56a0ca893efecbac9f989178',1,'pidData']]],
  ['desireddirection_1',['desiredDirection',['../struct_p_m_s_mflags.html#aff5a02b034517919d100fbc72aee2aad',1,'PMSMflags']]],
  ['divisiontable_2',['divisionTable',['../_p_m_s_mtables_8h.html#ad1c976744c3404db7cccfefb2ae1a04d',1,'PMSMtables.h']]],
  ['drivewaveform_3',['driveWaveform',['../struct_p_m_s_mflags.html#aeb3f44892dfb12dfdbd2cd23b536b030',1,'PMSMflags']]]
];
