var searchData=
[
  ['commutationticks_0',['commutationTicks',['../main_8c.html#a5236a7fb7ca5027e513e646a26972399',1,'main.c']]],
  ['csoffsetsforward_1',['CSOffsetsForward',['../_p_m_s_mtables_8h.html#a0a7921ae6c32e8b9cd5247d65496ce34',1,'PMSMtables.h']]],
  ['csoffsetsreverse_2',['CSOffsetsReverse',['../_p_m_s_mtables_8h.html#a19e7be833d50a052c96cf1b92f76e436',1,'PMSMtables.h']]],
  ['current_3',['current',['../main_8c.html#a2f35469b0fdf0c14123eafdbc42f59ae',1,'main.c']]]
];
