var searchData=
[
  ['waveform_5fblock_5fcommutation_0',['WAVEFORM_BLOCK_COMMUTATION',['../_p_m_s_m_8h.html#a022a4c94cc9e060104c70ba399633162',1,'PMSM.h']]],
  ['waveform_5fbraking_1',['WAVEFORM_BRAKING',['../_p_m_s_m_8h.html#a9b0d90086cc961c89952cf0b0afb132f',1,'PMSM.h']]],
  ['waveform_5fsinusoidal_2',['WAVEFORM_SINUSOIDAL',['../_p_m_s_m_8h.html#a26f2899b872b7970a2a70c56034620de',1,'PMSM.h']]],
  ['waveform_5fundefined_3',['WAVEFORM_UNDEFINED',['../_p_m_s_m_8h.html#a2af612381fa11ff5254d89cb16443444',1,'PMSM.h']]]
];
