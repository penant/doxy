var searchData=
[
  ['pid_5fcontroller_0',['PID_Controller',['../pid_8c.html#a0ba6abb47da779fec9bffc2d12653f12',1,'PID_Controller(int16_t setPoint, int16_t processValue, pidData_t *pid_st):&#160;pid.c'],['../pid_8h.html#a0ba6abb47da779fec9bffc2d12653f12',1,'PID_Controller(int16_t setPoint, int16_t processValue, pidData_t *pid_st):&#160;pid.c']]],
  ['pid_5finit_1',['PID_Init',['../pid_8c.html#ad57906d6e4e37706abf5eaf145be6879',1,'PID_Init(int16_t p_factor, int16_t i_factor, int16_t d_factor, pidData_t *pid):&#160;pid.c'],['../pid_8h.html#ad57906d6e4e37706abf5eaf145be6879',1,'PID_Init(int16_t p_factor, int16_t i_factor, int16_t d_factor, pidData_t *pid):&#160;pid.c']]],
  ['pid_5freset_5fintegrator_2',['PID_Reset_Integrator',['../pid_8c.html#a71b83d53883ce6a591fd70a9243f032c',1,'PID_Reset_Integrator(pidData_t *pid_st):&#160;pid.c'],['../pid_8h.html#a71b83d53883ce6a591fd70a9243f032c',1,'PID_Reset_Integrator(pidData_t *pid_st):&#160;pid.c']]]
];
