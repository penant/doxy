var indexSectionsWithContent =
{
  0: "abcdefhilmprstw",
  1: "p",
  2: "mp",
  3: "adehmpt",
  4: "abcdefilmps",
  5: "p",
  6: "abcdefhmprstw",
  7: "lm"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "defines",
  7: "pages"
};

var indexSectionLabels =
{
  0: "Tout",
  1: "Structures de données",
  2: "Fichiers",
  3: "Fonctions",
  4: "Variables",
  5: "Définitions de type",
  6: "Macros",
  7: "Pages"
};

