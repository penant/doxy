var searchData=
[
  ['blockcommutationtableforward_0',['blockCommutationTableForward',['../_p_m_s_mtables_8h.html#abc416187194dbb1a8cc2c509349f2435',1,'PMSMtables.h']]],
  ['blockcommutationtablereverse_1',['blockCommutationTableReverse',['../_p_m_s_mtables_8h.html#a13bec3275dd218557427f4de09b8699a',1,'PMSMtables.h']]]
];
