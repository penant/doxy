var searchData=
[
  ['block_5fcommutation_5fduty_5fmultiplier_0',['BLOCK_COMMUTATION_DUTY_MULTIPLIER',['../_p_m_s_m_8h.html#a6fafb9743a825b28157ac8d13dafc874',1,'PMSM.h']]]
];
