var searchData=
[
  ['actualdirection_0',['actualDirection',['../struct_p_m_s_mflags.html#a8d642421b25e2ae10190633371a1cf23',1,'PMSMflags']]],
  ['advancecommutationsteps_1',['advanceCommutationSteps',['../main_8c.html#a47b8e531c89b5eb9e807c0f28b0940d5',1,'main.c']]],
  ['amplitude_2',['amplitude',['../main_8c.html#a267f7577e1ed6402dc359e31b64431e8',1,'main.c']]]
];
