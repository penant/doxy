var searchData=
[
  ['rev_5frotation_5fpin_0',['REV_ROTATION_PIN',['../_p_m_s_m_8h.html#ab3f6c8cd5ba3b62b659dee0e41d584a6',1,'PMSM.h']]],
  ['reverse_5frotation_5fsignal_5fenable_1',['REVERSE_ROTATION_SIGNAL_ENABLE',['../_p_m_s_m_8h.html#acab30536f4bfeca3de321a138385d81a',1,'PMSM.h']]]
];
