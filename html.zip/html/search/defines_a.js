var searchData=
[
  ['scaling_5ffactor_0',['SCALING_FACTOR',['../pid_8h.html#a1dfc2df4edf95f828461ec28a276d36c',1,'pid.h']]],
  ['sine_5ftable_5flength_1',['SINE_TABLE_LENGTH',['../_p_m_s_m_8h.html#a78914577ac51d075945509b15a84ca09',1,'PMSM.h']]],
  ['speed_5fcontrol_5fclosed_5floop_2',['SPEED_CONTROL_CLOSED_LOOP',['../_p_m_s_m_8h.html#ab4a9f7aae0024ed0bc7634ecf451d0ae',1,'PMSM.h']]],
  ['speed_5fcontrol_5fmethod_3',['SPEED_CONTROL_METHOD',['../_p_m_s_m_8h.html#a58827487acb16c09d6d52669a1c177ce',1,'PMSM.h']]],
  ['speed_5fcontrol_5fopen_5floop_4',['SPEED_CONTROL_OPEN_LOOP',['../_p_m_s_m_8h.html#a59afdff3182a26c5e7f7ffb71ab1c32c',1,'PMSM.h']]],
  ['speed_5fcontroller_5fmax_5fincrement_5',['SPEED_CONTROLLER_MAX_INCREMENT',['../_p_m_s_m_8h.html#a08ae7c834b0245c9440b9c9575140358',1,'PMSM.h']]],
  ['speed_5fcontroller_5fmax_5finput_6',['SPEED_CONTROLLER_MAX_INPUT',['../_p_m_s_m_8h.html#a4d56b1ed29584505cb0491d85edba4d1',1,'PMSM.h']]],
  ['speed_5fcontroller_5ftime_5fbase_7',['SPEED_CONTROLLER_TIME_BASE',['../_p_m_s_m_8h.html#ab0d58795300e30ac9ba1600c434bd6dc',1,'PMSM.h']]],
  ['synchronization_5fcount_8',['SYNCHRONIZATION_COUNT',['../_p_m_s_m_8h.html#ad2f0d5dc57005ad15083f5bf69578503',1,'PMSM.h']]]
];
