var searchData=
[
  ['block_5fcommutation_5fduty_5fmultiplier_0',['BLOCK_COMMUTATION_DUTY_MULTIPLIER',['../_p_m_s_m_8h.html#a6fafb9743a825b28157ac8d13dafc874',1,'PMSM.h']]],
  ['blockcommutationtableforward_1',['blockCommutationTableForward',['../_p_m_s_mtables_8h.html#abc416187194dbb1a8cc2c509349f2435',1,'PMSMtables.h']]],
  ['blockcommutationtablereverse_2',['blockCommutationTableReverse',['../_p_m_s_mtables_8h.html#a13bec3275dd218557427f4de09b8699a',1,'PMSMtables.h']]]
];
