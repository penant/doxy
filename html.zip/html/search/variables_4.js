var searchData=
[
  ['expectedhallsequenceforward_0',['expectedHallSequenceForward',['../_p_m_s_mtables_8h.html#ac90deef7692f7f5bfb67e20eb1e9856e',1,'PMSMtables.h']]],
  ['expectedhallsequencereverse_1',['expectedHallSequenceReverse',['../_p_m_s_mtables_8h.html#a090b149986e6bf1effabdcbc9546dd58',1,'PMSMtables.h']]]
];
