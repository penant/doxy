var searchData=
[
  ['adc_5fchannel_5fcurrent_0',['ADC_CHANNEL_CURRENT',['../_p_m_s_m_8h.html#acc1eca038155957699dfcb680c6797da',1,'PMSM.h']]],
  ['adc_5fchannel_5fspeed_5fref_1',['ADC_CHANNEL_SPEED_REF',['../_p_m_s_m_8h.html#a434308b8515e774a8b558a2a9deb97f2',1,'PMSM.h']]],
  ['adc_5fprescaler_2',['ADC_PRESCALER',['../_p_m_s_m_8h.html#ab1d0703f6d84b37cbaa587a1a4515dd4',1,'PMSM.h']]],
  ['adc_5fprescaler_5f64_3',['ADC_PRESCALER_64',['../_p_m_s_m_8h.html#a51e4e47f4ef2b5f25be89b958a4bb8a8',1,'PMSM.h']]],
  ['adc_5fprescaler_5f8_4',['ADC_PRESCALER_8',['../_p_m_s_m_8h.html#ab30c91a0c1d57639fbb9aa2e13719d45',1,'PMSM.h']]],
  ['adc_5freference_5fvoltage_5',['ADC_REFERENCE_VOLTAGE',['../_p_m_s_m_8h.html#af557fa4300a3539ea54f1db1773e699f',1,'PMSM.h']]],
  ['adc_5freference_5fvoltage_5faref_6',['ADC_REFERENCE_VOLTAGE_AREF',['../_p_m_s_m_8h.html#a5f954d0687cfcb5fad241ee2c5896d1c',1,'PMSM.h']]],
  ['adc_5freference_5fvoltage_5finternal_7',['ADC_REFERENCE_VOLTAGE_INTERNAL',['../_p_m_s_m_8h.html#aead96d998d5be71e94f680cfe8129ee2',1,'PMSM.h']]],
  ['adc_5freference_5fvoltage_5fvcc_8',['ADC_REFERENCE_VOLTAGE_VCC',['../_p_m_s_m_8h.html#a2cf73c0f278eabd290cfd15bc2a407bf',1,'PMSM.h']]],
  ['admux_5fcurrent_9',['ADMUX_CURRENT',['../_p_m_s_m_8h.html#ac6bf33c6961983cea70bfbf8f6e59019',1,'PMSM.h']]],
  ['admux_5fspeed_5fref_10',['ADMUX_SPEED_REF',['../_p_m_s_m_8h.html#ac0b5ae63fe430c4cf1001b059d88e3f5',1,'PMSM.h']]]
];
