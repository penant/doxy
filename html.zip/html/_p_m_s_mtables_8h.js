var _p_m_s_mtables_8h =
[
    [ "blockCommutationTableForward", "_p_m_s_mtables_8h.html#abc416187194dbb1a8cc2c509349f2435", null ],
    [ "blockCommutationTableReverse", "_p_m_s_mtables_8h.html#a13bec3275dd218557427f4de09b8699a", null ],
    [ "CSOffsetsForward", "_p_m_s_mtables_8h.html#a0a7921ae6c32e8b9cd5247d65496ce34", null ],
    [ "CSOffsetsReverse", "_p_m_s_mtables_8h.html#a19e7be833d50a052c96cf1b92f76e436", null ],
    [ "divisionTable", "_p_m_s_mtables_8h.html#ad1c976744c3404db7cccfefb2ae1a04d", null ],
    [ "expectedHallSequenceForward", "_p_m_s_mtables_8h.html#ac90deef7692f7f5bfb67e20eb1e9856e", null ],
    [ "expectedHallSequenceReverse", "_p_m_s_mtables_8h.html#a090b149986e6bf1effabdcbc9546dd58", null ],
    [ "sineTable", "_p_m_s_mtables_8h.html#aab225db82be54b100ea31ae52dc6c745", null ]
];