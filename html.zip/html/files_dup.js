var files_dup =
[
    [ "main.c", "main_8c.html", "main_8c" ],
    [ "pid.c", "pid_8c.html", "pid_8c" ],
    [ "pid.h", "pid_8h.html", "pid_8h" ],
    [ "PMSM.h", "_p_m_s_m_8h.html", "_p_m_s_m_8h" ],
    [ "PMSMtables.h", "_p_m_s_mtables_8h.html", "_p_m_s_mtables_8h" ],
    [ "stdint.h", "stdint_8h_source.html", null ]
];