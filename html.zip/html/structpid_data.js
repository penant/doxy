var structpid_data =
[
    [ "D_Factor", "structpid_data.html#a1a90165f56a0ca893efecbac9f989178", null ],
    [ "I_Factor", "structpid_data.html#a338fc64ccceaf6669e2a9290536b492d", null ],
    [ "lastProcessValue", "structpid_data.html#abfb07b8efb17bb0101ba461d8a9302f1", null ],
    [ "maxError", "structpid_data.html#abc0df1fd5606b1d182ba271c813dfd8e", null ],
    [ "maxSumError", "structpid_data.html#a4c337276f8b8dc3ae72afb2b371f1e48", null ],
    [ "P_Factor", "structpid_data.html#a22c3cbc2ef78517e2adceb8a96264674", null ],
    [ "sumError", "structpid_data.html#a9a15e70f2e089d19604b05bdedfc4f81", null ]
];