var main_8c =
[
    [ "ADCCompleteISR", "main_8c.html#a81b96d769ccd714c99b4cd618bd5b5a1", null ],
    [ "DirectionInputChangeISR", "main_8c.html#a98d5f4c53c953a3ccd703d80cb1b3ad2", null ],
    [ "EmergencyInterruptISR", "main_8c.html#a040267cb0c05305d47c9ec3c9a6ddb67", null ],
    [ "HallChangeISR", "main_8c.html#a4fd8edebfdabcff124a24836675772de", null ],
    [ "main", "main_8c.html#a6288eba0f8e8ad3ab1544ad731eb7667", null ],
    [ "Timer1CaptureISR", "main_8c.html#a3d40738f9a13e5ed7c3a4260a44c3ce6", null ],
    [ "advanceCommutationSteps", "main_8c.html#a47b8e531c89b5eb9e807c0f28b0940d5", null ],
    [ "amplitude", "main_8c.html#a267f7577e1ed6402dc359e31b64431e8", null ],
    [ "commutationTicks", "main_8c.html#a5236a7fb7ca5027e513e646a26972399", null ],
    [ "current", "main_8c.html#a2f35469b0fdf0c14123eafdbc42f59ae", null ],
    [ "fastFlags", "main_8c.html#adfb43fcb0bf029671dec8793ca9bb5f0", null ],
    [ "sineTableIncrement", "main_8c.html#aeb5d4222d7403f250a80f7f855195516", null ],
    [ "sineTableIndex", "main_8c.html#a39d14b66ed91fa1c41eb87b0f9995aec", null ],
    [ "sineTableNextSectorStart", "main_8c.html#a7001a59ce11ed2cc2d7dccf82b688bf0", null ],
    [ "SpeedControllerRun", "main_8c.html#a307585cf5a96ca4e8c6f6ba71850c527", null ],
    [ "speedInput", "main_8c.html#a59c86107a73bee0db19e4628673164ae", null ]
];