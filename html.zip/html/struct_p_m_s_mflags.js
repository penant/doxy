var struct_p_m_s_mflags =
[
    [ "actualDirection", "struct_p_m_s_mflags.html#a8d642421b25e2ae10190633371a1cf23", null ],
    [ "desiredDirection", "struct_p_m_s_mflags.html#aff5a02b034517919d100fbc72aee2aad", null ],
    [ "driveWaveform", "struct_p_m_s_mflags.html#aeb3f44892dfb12dfdbd2cd23b536b030", null ],
    [ "motorSynchronized", "struct_p_m_s_mflags.html#a8f757d0da362603a85729ad0ea70e9b4", null ]
];