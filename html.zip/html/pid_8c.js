var pid_8c =
[
    [ "PID_Controller", "pid_8c.html#a0ba6abb47da779fec9bffc2d12653f12", null ],
    [ "PID_Init", "pid_8c.html#ad57906d6e4e37706abf5eaf145be6879", null ],
    [ "PID_Reset_Integrator", "pid_8c.html#a71b83d53883ce6a591fd70a9243f032c", null ]
];